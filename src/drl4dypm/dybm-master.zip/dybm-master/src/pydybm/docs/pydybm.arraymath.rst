pydybm\.arraymath package
=========================

Subpackages
-----------

.. toctree::

    pydybm.arraymath.dycupy
    pydybm.arraymath.dynumpy

Module contents
---------------

.. automodule:: pydybm.arraymath
    :members:
    :undoc-members:
    :show-inheritance:
