pydybm\.base\.sgd module
========================

.. automodule:: pydybm.base.sgd
    :members:
    :undoc-members:
    :show-inheritance:
