pydybm\.arraymath\.dynumpy\.operations module
=============================================

.. automodule:: pydybm.arraymath.dynumpy.operations
    :members:
    :undoc-members:
    :show-inheritance:
