pydybm\.base package
====================

Submodules
----------

.. toctree::

   pydybm.base.generator
   pydybm.base.metrics
   pydybm.base.sgd
